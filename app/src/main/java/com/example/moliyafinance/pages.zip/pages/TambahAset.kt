package com.example.moliyafinance.pages


import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.example.moliyafinance.Variables
import com.example.moliyafinance.databinding.ActivityAsetBinding

class TambahAset : AppCompatActivity() {
    private lateinit var bind : ActivityAsetBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bind = ActivityAsetBinding.inflate(layoutInflater)
        setContentView(bind.root)
        init()
    }
    private fun init(){
        bind.back.setOnClickListener {
            finish()
        }

        val arraySpinnerAset = ArrayList<String>()
        for (data in Variables.akunList) {
            if (data.kategori == "Harta Tetap") {
                arraySpinnerAset.add(data.kategori)
            }
        }

        val spinnerAsetAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, arraySpinnerAset)
        bind.spinnerAkunAset.adapter = spinnerAsetAdapter
    }
}